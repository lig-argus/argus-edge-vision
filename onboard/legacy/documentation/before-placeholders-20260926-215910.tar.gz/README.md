# ARGUS — C++ 실행 구조 + Python 영상 작업자

현행 실행 코드는 `/home/user/npu-test/work/argus_vision_bus`다.
사용자 전체 흐름도를 기준으로 입력·큐·조립·관측·통신 접점은 C++로 구현했다.
전처리·YOLOX·Pi의 박스/JPEG·버스 중계·점검 도구는 Python에 유지했다.
다른 AI는 [AGENTS.md](AGENTS.md)의 결정과 [전환 기록](docs/CPP_MIGRATION.md)을 먼저 읽는다.

## 폴더

```text
argus_vision_bus/
├── AGENTS.md                 AI 작업 규칙 / 자동 원복 금지
├── CMakeLists.txt            전체 C++ 빌드 진입
├── cpp/
│   ├── apps/                 OnboardMain / FrameSourceCapture
│   ├── include/argus/
│   │   ├── contracts/        Frame / Observation / Track / CommandRequest
│   │   ├── ports/            IClock / IFrameSource / IDetector / ITracker / ICameraMotion / IVehiclePort
│   │   ├── application/      CompositionRoot / PerceptionWorker / FrameQueue / BoxPostprocessor / Recorder
│   │   └── adapters/         I3SdkFrameSource / OpenCvFrameSource / PythonVisionAdapter / MessageBus
│   ├── src/                  같은 역할의 .cpp 구현
│   └── tests/                C++ 계약 검증
├── python/argus_workers/
│   ├── perception/           Preprocessor / YOLOXDetector / OverlayEncoder / PythonVisionWorker
│   ├── transport/            BusProxy / MessageBus / Protocol / Topics
│   └── tools/                HardwareCheck / PreviewSubscriber / DetectionSubscriber / OnboardLauncher
├── config/                   기존 profiles.toml / runtime.env / 라벨
├── models/                   기존 HEF (변경하지 않음)
├── scripts/                  build / setup / run / service
├── tests/integration/        C++ ↔ Python ↔ Bus 실제 전달·종료 검증
├── docs/                     설계·부품 위치·실행 방법
│   └── design/               사용자 흐름도 원본 사본
└── legacy/                   참고 원본. 실행 대상 아님
    ├── python/               기존 .py를 .py.org로 보관 + SHA256 manifest
    ├── launchers/            이전 실행·패키지 설정
    └── documentation/        이전 문서
```

## 현재 실행 흐름

```mermaid
flowchart TD
    CONFIG[환경 프로파일] --> ROOT[C++ CompositionRoot]
    ROOT --> SOURCE[C++ IFrameSource]
    SDK[기존 C++ SDK 캡처] --> SOURCE
    CV[C++ V4L2 / Replay 캡처] --> SOURCE
    SOURCE --> QUEUE[C++ FrameQueue / 기본 2 / FIFO drop-oldest]
    QUEUE --> BRIDGE[C++ PythonVisionAdapter]
    BRIDGE -->|전용 IPC / 프레임 + 메타데이터| PRE[Python Preprocessor]
    PRE --> YOLO[Python YOLOXDetector / Hailo]
    YOLO -->|원본 좌표 full_box| BOX[C++ BoxPostprocessor / Observation]
    BOX --> BUS[C++ MessageBus → Python BusProxy]
    BUS --> SUB[perception/observations 구독자]
    PRE --> OVLY[Python OverlayEncoder / 별도 스레드]
    YOLO --> OVLY
    OVLY -->|박스 포함 JPEG / 전용 IPC| RELAY[C++ 영상 발행]
    RELAY --> BUS
    BUS -->|Wi-Fi / vision/overlay/jpeg| PC[PC / Windows 미리보기]
    BOX -. 미구현 .-> TRACK[ITracker + CameraMotion]
    TRACK -. 미구현 .-> STORE[tracking/tracks → LatestStateStore]
    STORE -. 미구현 .-> CONTROL[독립 제어 / FSM / Guard / Watchdog]
    CONTROL -. 미구현 .-> PORT[단일 VehiclePort]
```

Pi에서 bbox와 영상을 합친다. PC에서 별도 좌표를 합성하는 방식이 아니다.
FrameQueue와 미리보기 큐는 다른 목적이다. 인지 큐의 정책/기본 용량 2는 보존했다.

## 실행

빌드 의존성이 준비된 환경:

```bash
cd /home/user/npu-test/work/argus_vision_bus
bash scripts/setup_rpi.sh
bash scripts/service_entrypoint.sh check
bash scripts/run_rpi.sh
```

Pi JPEG 미리보기도 발행:

```bash
bash scripts/run_rpi.sh models/yolox_s_leaky_hailo8_zoo_v2.19.0.hef /dev/video0 config/coco80.txt --preview
```

PC/Windows에는 `vision/overlay/jpeg` 구독자가 필요하다. 같은 Wi-Fi에서:

```bash
argus-preview-sub --endpoint tcp://<Pi의-Wi-Fi-IP>:5556
```

SDK 카메라를 쓰려면 `ARGUS_FRAME_SOURCE=ir_sdk`를 사용한다.
실제 runtime.env/profiles.toml과 모델은 전환 과정에서 바꾸지 않았다. 기존 기본 입력이 V4L2면 그대로다.
모델·카메라가 없는 검증은 [통합 검사](docs/CPP_MIGRATION.md)를 참고한다.

## 구현 범위

현재 공개 발행은 관측·진단·옵션 JPEG다. 실제 MOT, FC 회전 CMC, 노출/FC 시각 정렬,
원자적 제어 상태 저장소, 전체 임무 FSM, Guard/Watchdog, VehiclePort 실행은 아직 없다.
인터페이스가 있다는 이유로 완료됐다고 간주하지 않는다. 기체 연결이나 명령 송신을 시작하지 않는다.

- [흐름도 준수와 미구현 목록](docs/FLOW_ALIGNMENT.md)
- [흐름도 이름 ↔ 실제 파일](docs/FILE_MAP.md)
- [통신 규약](docs/BUS_CONTRACT.md)
- [입력·모델](docs/CAMERA_AND_MODEL_NOTES.md)
- [C++ 전환 결정·검증·보관](docs/CPP_MIGRATION.md)
