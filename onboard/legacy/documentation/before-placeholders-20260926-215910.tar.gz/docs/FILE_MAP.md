# 흐름도 이름과 파일

파일 이름은 각 부품 역할을 사용한다. .hpp는 계약/선언, .cpp는 구현이다.

| 흐름도 역할 | 현행 파일 |
|---|---|
| 환경 프로파일 | cpp/include/argus/application/EnvironmentProfile.hpp / cpp/src/application/EnvironmentProfile.cpp |
| CompositionRoot | cpp/include/argus/application/CompositionRoot.hpp / cpp/src/application/CompositionRoot.cpp |
| 실행 진입 | cpp/apps/OnboardMain.cpp |
| IClock | cpp/include/argus/ports/IClock.hpp / cpp/src/contracts/SystemClock.cpp |
| 프레임/시각 | cpp/include/argus/contracts/Frame.hpp |
| IFrameSource | cpp/include/argus/ports/IFrameSource.hpp |
| SDK 입력 | cpp/include/argus/adapters/I3SdkFrameSource.hpp / cpp/src/adapters/I3SdkFrameSource.cpp |
| V4L2/Replay 입력 | cpp/include/argus/adapters/OpenCvFrameSource.hpp / cpp/src/adapters/OpenCvFrameSource.cpp |
| C++ 카메라 읽기 helper | cpp/apps/FrameSourceCapture.cpp |
| 유계 큐 | cpp/include/argus/application/FrameQueue.hpp |
| 인지 실행 | cpp/include/argus/application/PerceptionWorker.hpp / cpp/src/application/PerceptionWorker.cpp |
| 전처리 | python/argus_workers/perception/Preprocessor.py |
| IDetector | cpp/include/argus/ports/IDetector.hpp |
| Python 연결 | cpp/include/argus/adapters/PythonVisionAdapter.hpp / cpp/src/adapters/PythonVisionAdapter.cpp |
| Python 영상 요청 처리 | python/argus_workers/perception/PythonVisionWorker.py |
| YOLOX | python/argus_workers/perception/YOLOXDetector.py |
| BoxPostprocessor | cpp/include/argus/application/BoxPostprocessor.hpp |
| Observation | cpp/include/argus/contracts/Observation.hpp |
| Track/TTL | cpp/include/argus/contracts/Track.hpp |
| OverlayEncoder | python/argus_workers/perception/OverlayEncoder.py |
| Pub/Sub | cpp/include/argus/adapters/MessageBus.hpp / cpp/src/adapters/MessageBus.cpp |
| 버스 중계 | python/argus_workers/transport/BusProxy.py |
| Recorder | cpp/include/argus/application/Recorder.hpp / cpp/src/application/Recorder.cpp |
| CommandGateway 자료형 | cpp/include/argus/contracts/CommandRequest.hpp |
| Tracker 계약만 | cpp/include/argus/ports/ITracker.hpp |
| CameraMotion 계약만 | cpp/include/argus/ports/ICameraMotion.hpp |
| VehiclePort 계약만 | cpp/include/argus/ports/IVehiclePort.hpp |
| 미리보기 수신 | python/argus_workers/tools/PreviewSubscriber.py |

Tracker/CameraMotion/VehiclePort 헤더가 있다고 해당 기능이 실행되는 것은 아니다.
미구현 제어 노드의 가짜 .cpp를 만들지 않았다. 기존 PC C++ 시험 모듈은 /home/user/project/코드/px4_follow_sitl/cpp 에 있다.
이 패키지의 실제 IR 경로와 PC 시험용 단일 박스/AlphaBeta 경로를 같은 구현으로 간주하지 않는다.
