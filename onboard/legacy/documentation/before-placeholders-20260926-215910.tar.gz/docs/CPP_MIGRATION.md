# C++ 전환 결정 — 2026-09-26

사용자는 추천 항목 1~5의 C++ 부분을 구현하도록 승인했다.
전처리·YOLOX를 Python에 남기며, 6번(박스/JPEG)의 전면 C++ 전환은 보류했다.
영상과 bbox는 Pi에서 합쳐 전송하는 원래 방식을 다시 명시했다.
이 문서는 다른 AI가 과거 Python 전체 실행부로 자동 원복하지 않도록 결정과 근거를 기록한다.
사용자의 이후 명시적 변경 요청은 이 기록보다 우선한다.

| 항목 | 구현 | Python 유지 |
|---|---|---|
| 1 계약 | C++ Frame/Observation/Track/CommandRequest, ports | 영상 작업자 출력 자료형/MessagePack 변환 |
| 2 입력/큐 | 기존 SDK 실행 파일 재사용, C++ SDK/V4L2/Replay 어댑터, FrameQueue | RAW14 영상 변환 |
| 3 연결 | C++ OwnedProcess/PythonVisionAdapter, private IPC, readiness/timeout/identity 검사 | PythonVisionWorker의 최소 REP 요청 처리 |
| 4 실행 | OnboardMain/CompositionRoot/PerceptionWorker, source thread, fault/cleanup | 전처리·YOLOX·JPEG 작업자 |
| 5 통신 | C++ MessageBus로 관측/진단/JPEG 발행 | BusProxy, 구독·점검 도구 |
| 6 미리보기 | C++는 JPEG를 받아 발행 | Pi의 OverlayEncoder에서 박스/JPEG 별도 스레드 |

## SDK 재사용

SDK 자체를 다시 작성하지 않았다. 기존 `i3_raw14_capture`의 I3R4 40바이트 헤더와 RAW14 LE16을 읽는다.
SDK 프로세스의 재사용 버퍼 복사·14비트 범위 검사·오래된 프레임 덮어쓰기·정지 정책은 그대로다.
캡처 프로세스는 SDK의 막힌 수신/강제 종료가 상위 실행부를 직접 종료시키지 않도록 분리한다.
OpenCV 캡처도 별도 C++ helper로 분리했고 상위 입력 어댑터는 poll/timeout으로 종료 요청에 응답한다.

## 계약 보존

- 인지 큐는 용량 2의 FIFO, 가득 차면 oldest 폐기다. 처리 중 Python 요청은 하나다.
- Python 모델 및 letterbox/RAW14 변환 수식을 재사용했다. C++는 반환된 원본 픽셀 full_box를 검증한다.
- worker private IPC에는 session_id/frame_id가 있으며 다른 프레임/세션 응답을 거부한다.
- 공개 관측 schema v2의 23개 필드는 기존 형식을 보존했다. 내부 session_id를 공개 관측에 추가하지 않았다.
- 원본 박스의 track_id는 null이다. 아직 실제 Tracker가 없다.
- 수신/SDK 콜백 시각과 노출 시각을 구분한다. 현재 exposure_time_valid=false다.
- 프레임 시각·예측 TTL 계약을 C++ 단위 검사로 확인한다.
- C++와 Python은 같은 Linux 호스트의 CLOCK_MONOTONIC ns를 사용한다.
- CSV의 queue_dwell_ms는 이번 버전에서는 host receipt→C++ 처리 시작이다. 이전 put→get 지표와 그대로 비교하지 않는다.
- 새 CSV는 IPC 시간을 따로 기록하며 이전 세부 Hailo 측정 CSV는 legacy 문서로 보존한다.

## Python 원본 보관

`legacy/python/src/argus_vision/*.py.org`, `legacy/python/tests/*.py.org`에 원본 바이트를 보관했다.
`legacy/python/manifest.json`은 SHA256이다. 파일 이름 변경은 실행/import 방지 목적이다.
재사용한 Python 구현은 `python/argus_workers/`에서 역할별 새 이름으로 관리한다.
과거 소스를 .py로 복원하거나 실행 경로에 넣는 자동 fallback은 금지한다.
원본 복구가 정말 필요한 경우 사용자 요청을 받은 뒤 백업을 별도 작업 폴더에 검토한다.

## 빌드 의존성

기존 HailoRT, Python 가상환경, SDK와 HEF를 재사용한다.
필요한 Ubuntu 개발 패키지:

```bash
sudo apt-get install pkg-config libzmq3-dev libmsgpack-dev libtomlplusplus-dev   libopencv-core-dev libopencv-imgproc-dev libopencv-imgcodecs-dev libopencv-videoio-dev
bash scripts/setup_rpi.sh
```

setup은 새 Python 패키지를 editable로 설치하고 C++를 빌드한다. Python orchestration fallback은 없다.

## 검증 명령

```bash
bash scripts/build.sh
.venv-rpi/bin/python -m pytest tests/integration -q
```

검사는 합성 영상 Replay, 실제 C++ SDK 실행 파일의 --test-pattern, Mock Detector,
ZeroMQ 프록시 전달/종료, JPEG/프레임 ID, 작업자 실패/지연/잘못된 응답을 사용한다.
Hailo smoke는 ARGUS_HEF_SMOKE를 지정했을 때 합성 영상으로 실행한다. 실제 카메라/비행 검사가 아니다.
최종 결과와 배포 백업 위치는 docs/VALIDATION.md에 기록한다.
